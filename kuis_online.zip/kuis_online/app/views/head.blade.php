<meta charset="utf-8">
<meta name="description" content="deskripsi">
<meta name="author" content="Hendrawan Kuncoro">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Aegis ORG &raquo; Kuis Online</title>
{{HTML::style('css/bootstrap.min.css');}}
{{HTML::style('css/bootstrap-wysihtml5.css');}}
{{HTML::style('css/slider.css');}}
<style>
    body {
        padding-top: 70px;
        
    }
</style>