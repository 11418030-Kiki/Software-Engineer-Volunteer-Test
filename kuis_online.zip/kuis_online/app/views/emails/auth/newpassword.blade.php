<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>New Password</h2>

<p>Here is your new password:</p>

<p>
<blockquote>{{{ $newPassword }}}</blockquote>
</p>
<p>Thank you, <br/>
    ~The Admin Team</p>
</body>
</html>