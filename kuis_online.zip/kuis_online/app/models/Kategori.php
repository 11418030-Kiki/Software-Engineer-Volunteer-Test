<?php

class Kategori extends KategoriBase
{
    //put custom code here... look in the base class for generated relations..

}