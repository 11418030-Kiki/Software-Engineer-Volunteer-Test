<?php
class Jawaban extends JawabanBase
{
    //put custom code here... look in the base class for generated relations..

}