<?php

class Lembar extends LembarBase
{
    //put custom code here... look in the base class for generated relations..

}