<?php

class SoalHasLembar extends SoalHasLembarBase
{
    //put custom code here... look in the base class for generated relations..

}