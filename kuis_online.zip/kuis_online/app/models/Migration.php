<?php


class Migration extends MigrationBase{
    //put custom code here... look in the base class for generated relations..
}

}