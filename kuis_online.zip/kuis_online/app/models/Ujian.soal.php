<?php

class Ujian.soal extends Eloquent {
	
    protected
    $guarded = array();

    public
    static $rules = array();
}
