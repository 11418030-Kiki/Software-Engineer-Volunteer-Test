<?php

class SoalsTableSeeder extends Seeder
{

    public function run()
    {
       

        $soals = array();

        // Uncomment the below to run the seeder
        // DB::table('soals')->insert($soals);
    }

}
