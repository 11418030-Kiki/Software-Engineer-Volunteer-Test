<?php

class LembarsTableSeeder extends Seeder
{

    public function run()
    {
        // Uncomment the below to wipe the table clean before populating
        // DB::table('lembars')->truncate();

        $lembars = array();

        // Uncomment the below to run the seeder
        // DB::table('lembars')->insert($lembars);
    }

}
