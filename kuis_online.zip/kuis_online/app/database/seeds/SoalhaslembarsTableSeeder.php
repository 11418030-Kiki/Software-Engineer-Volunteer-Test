<?php

class SoalhaslembarsTableSeeder extends Seeder
{

    public function run()
    {
        
        // DB::table('soalhaslembars')->truncate();

        $soalhaslembars = array();

        // Uncomment the below to run the seeder
        // DB::table('soalhaslembars')->insert($soalhaslembars);
    }

}
