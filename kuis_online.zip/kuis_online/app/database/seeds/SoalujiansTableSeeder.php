<?php

class SoalujiansTableSeeder extends Seeder
{

    public function run()
    {
        // DB::table('soalujians')->truncate();

        $soalujians = array();

        // Uncomment the below to run the seeder
        // DB::table('soalujians')->insert($soalujians);
    }

}
