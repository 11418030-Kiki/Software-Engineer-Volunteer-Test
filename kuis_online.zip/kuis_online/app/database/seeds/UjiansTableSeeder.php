<?php

class UjiansTableSeeder extends Seeder
{

    public function run()
    {
        // Uncomment the below to wipe the table clean before populating
        // DB::table('ujians')->truncate();

        $ujians = array();

      
    }

}
