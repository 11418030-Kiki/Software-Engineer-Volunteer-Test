<?php namespace Authority\Repo;

abstract class RepoAbstract
{


}